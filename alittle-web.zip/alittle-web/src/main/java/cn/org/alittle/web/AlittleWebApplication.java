package cn.org.alittle.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlittleWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlittleWebApplication.class, args);
	}

}
